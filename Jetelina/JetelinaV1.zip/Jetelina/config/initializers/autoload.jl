# Optional flat/non-resource MVC folder structure
# push!(LOAD_PATH,  "controllers", "models")